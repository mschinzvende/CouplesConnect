﻿// ===============================
// Media Manager
// Couples Connect
// ===============================

export default class MediaManager {

    constructor() {

        this.localStream = null;
        this.screenStream = null;

        this.cameraEnabled = true;
        this.microphoneEnabled = true;

        this.onLocalStreamReady = null;
    }

    // ===============================
    // Initialize Camera + Microphone
    // ===============================

    async initialize() {

        if (this.localStream)
            return this.localStream;

        try {

            console.log("[Media] Requesting camera...");

            this.localStream = await navigator.mediaDevices.getUserMedia({

                video: {
                    width: { ideal: 1280 },
                    height: { ideal: 720 },
                    frameRate: { ideal: 30 }
                },

                audio: {

                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true

                }

            });

            console.log("[Media] Camera ready");

            if (this.onLocalStreamReady)
                this.onLocalStreamReady(this.localStream);

            return this.localStream;

        }
        catch (err) {

            console.error("[Media] Failed:", err);

            alert("Unable to access camera or microphone.");

            throw err;

        }

    }

    // ===============================
    // Local Stream
    // ===============================

    getStream() {

        return this.localStream;

    }

    // ===============================
    // Toggle Microphone
    // ===============================

    toggleMicrophone() {

        if (!this.localStream)
            return false;

        this.microphoneEnabled = !this.microphoneEnabled;

        this.localStream
            .getAudioTracks()
            .forEach(track => {

                track.enabled = this.microphoneEnabled;

            });

        console.log("[Media] Microphone:",
            this.microphoneEnabled ? "ON" : "OFF");

        return this.microphoneEnabled;

    }

    // ===============================
    // Toggle Camera
    // ===============================

    toggleCamera() {

        if (!this.localStream)
            return false;

        this.cameraEnabled = !this.cameraEnabled;

        this.localStream
            .getVideoTracks()
            .forEach(track => {

                track.enabled = this.cameraEnabled;

            });

        console.log("[Media] Camera:",
            this.cameraEnabled ? "ON" : "OFF");

        return this.cameraEnabled;

    }

    // ===============================
    // Share Screen
    // ===============================

    async startScreenShare() {

        try {

            this.screenStream =
                await navigator.mediaDevices.getDisplayMedia({

                    video: true

                });

            console.log("[Media] Screen sharing started");

            return this.screenStream;

        }
        catch (err) {

            console.error(err);

            return null;

        }

    }

    stopScreenShare() {

        if (!this.screenStream)
            return;

        this.screenStream
            .getTracks()
            .forEach(track => track.stop());

        this.screenStream = null;

        console.log("[Media] Screen sharing stopped");

    }

    // ===============================
    // Attach Stream to Video
    // ===============================

    attach(videoElement, stream, muted = false) {

        if (!videoElement)
            return;

        videoElement.srcObject = stream;

        videoElement.autoplay = true;

        videoElement.playsInline = true;

        videoElement.muted = muted;

        videoElement.play()
            .catch(err => console.log(err));

    }

    // ===============================
    // Stop Everything
    // ===============================

    stop() {

        if (this.screenStream) {

            this.screenStream
                .getTracks()
                .forEach(track => track.stop());

            this.screenStream = null;

        }

        if (this.localStream) {

            this.localStream
                .getTracks()
                .forEach(track => track.stop());

            this.localStream = null;

        }

        console.log("[Media] Streams stopped");

    }

}